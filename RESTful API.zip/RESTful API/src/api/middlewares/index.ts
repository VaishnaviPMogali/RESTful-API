import example from './example'

export default {
  example
}
