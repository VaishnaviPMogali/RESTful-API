const example = async (req, res, next): Promise<void> => {
  next()
}

export default example
